window.YHSERVICECONFIG = {
  base: ''
}
